from pathlib import Path

import pandas as pd
import pytest

from pim_matcher import match
from pim_matcher.io import guess_columns, read_table
from pim_matcher.normalize import normalize_code, parse_name

DATA = Path(__file__).parent.parent / "sample_data"
VCOLS = {"name": "vendor_product", "id": "vendor_sku", "brand": "vendor_brand", "barcode": "gtin"}
PCOLS = {"name": "product_name", "id": "pim_id", "brand": "brand", "barcode": "barcode"}


@pytest.fixture(scope="module")
def result():
    v = read_table(DATA / "vendor_sample.csv")
    p = read_table(DATA / "pim_sample.csv")
    return match(v, p, VCOLS, PCOLS)


def by_vendor(result, vid):
    t = result.table
    return t[t["vendor_id"] == vid].iloc[0]


@pytest.mark.parametrize(
    "text,kind,value",
    [
        ("Milk 1 LTR", "ml", 1000),
        ("Coffee 100 gm", "g", 100),
        ("Noodles 5x70g", "g", 350),
        ("Cola 330ml x 6", "ml", 1980),
        ("Nutella 1,5kg", "g", 1500),
        ("Tea 100 bags", "count", 100),
        ("هاينز كاتشب ٤٦٠ جم", "g", 460),
        ("Galaxy S23 128 GB", "gb", 128),
    ],
)
def test_size_parsing(text, kind, value):
    s = parse_name(text).size
    assert s is not None and s.kind == kind and s.value == pytest.approx(value)


def test_no_size_inside_model_numbers():
    assert parse_name("Galaxy S23 Black").size is None


def test_barcode_normalisation():
    assert normalize_code("0006281007010011") == "6281007010011"
    assert normalize_code("123") == ""


def test_exact_matches_are_auto(result):
    for vid, pim in [("V001", "P001"), ("V011", "P012"), ("V016", "P017"), ("V022", "P022")]:
        r = by_vendor(result, vid)
        assert r["status"] == "auto" and r["pim_id"] == pim


def test_size_distinguishes_variants(result):
    assert by_vendor(result, "V013")["pim_id"] == "P014"  # 750 g, not 350 g


def test_model_number_distinguishes_variants(result):
    assert by_vendor(result, "V024")["pim_id"] == "P023"
    assert by_vendor(result, "V025")["pim_id"] == "P024"


def test_barcode_forces_match(result):
    r = by_vendor(result, "V005")
    assert r["status"] == "auto" and r["pim_id"] == "P006" and r["method"] == "barcode"


def test_products_not_in_pim_are_no_match(result):
    assert by_vendor(result, "V021")["status"] == "no_match"
    assert by_vendor(result, "V023")["status"] == "no_match"


def test_shorter_vendor_names_reach_review_or_auto(result):
    for vid in ("V003", "V012", "V015", "V018"):
        assert by_vendor(result, vid)["status"] in ("auto", "review")


def test_finalize_applies_decisions(result):
    pos = result.table.index[result.table["vendor_id"] == "V012"][0]
    final = result.finalize({pos: result.candidates[pos][0].pim_idx})
    assert final.loc[pos, "final_status"] == "confirmed"
    assert final.loc[pos, "final_pim_id"] == "P013"
    final = result.finalize({pos: None})
    assert final.loc[pos, "final_status"] == "no_match (reviewed)"


def test_search_pim(result):
    hits = result.search_pim("nutella 750")
    assert hits and "Nutella" in hits[0].pim_name


def test_guess_columns():
    g = guess_columns(read_table(DATA / "vendor_sample.csv"))
    assert g["name"] == "vendor_product" and g["barcode"] == "gtin" and g["brand"] == "vendor_brand"


def test_empty_pim_does_not_crash():
    v = pd.DataFrame({"n": ["Milk 1L"]})
    p = pd.DataFrame({"n": []})
    r = match(v, p, {"name": "n"}, {"name": "n"})
    assert r.table.loc[0, "status"] == "no_match"
