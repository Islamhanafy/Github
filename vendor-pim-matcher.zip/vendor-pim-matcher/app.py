"""Vendor <-> PIM product matcher (Streamlit app).

Run:  streamlit run app.py
"""
from __future__ import annotations

import os

import pandas as pd
import streamlit as st

from pim_matcher import (
    MatchConfig,
    guess_columns,
    list_sheets,
    match,
    read_table,
    to_csv_bytes,
    to_excel_bytes,
)

st.set_page_config(page_title="Vendor to PIM matcher", page_icon="🔗", layout="wide")

NONE = "(none)"
ss = st.session_state
for key, default in {
    "vendor_df": None, "pim_df": None, "result": None,
    "decisions": {}, "queue_pos": 0,
}.items():
    ss.setdefault(key, default)

REVIEW_STATUSES = ("review", "llm_suggested")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def load_file(label: str, key: str):
    up = st.file_uploader(label, type=["csv", "tsv", "txt", "xlsx", "xls"], key=f"{key}_file")
    if up is None:
        return None
    sheet = None
    sheets = list_sheets(up)
    if len(sheets) > 1:
        sheet = st.selectbox("Sheet", sheets, key=f"{key}_sheet")
    try:
        return read_table(up, sheet=sheet)
    except Exception as e:
        st.error(f"Could not read this file: {e}")
        return None


def column_picker(prefix: str, df: pd.DataFrame) -> dict:
    cols = list(df.columns)
    guess = guess_columns(df)

    def idx(col, optional):
        options = ([NONE] if optional else []) + cols
        return options.index(col) if col in options else 0

    name = st.selectbox("Product name column", cols, index=idx(guess["name"], False), key=f"{prefix}_c_name")
    opt = {}
    for k, label in (("id", "ID / SKU column"), ("brand", "Brand column"), ("barcode", "Barcode (GTIN/EAN) column")):
        v = st.selectbox(f"{label} (optional)", [NONE] + cols, index=idx(guess[k], True), key=f"{prefix}_c_{k}")
        opt[k] = None if v == NONE else v
    return {"name": name, **opt}


def pct(n: int, total: int) -> str:
    return f"{(100 * n / total):.0f}%" if total else "-"


def candidate_label(c) -> str:
    brand = f" [{c.pim_brand}]" if c.pim_brand else ""
    return f"{c.pim_name}{brand}  -  score {c.score:.0f}"


# --------------------------------------------------------------------------
# header
# --------------------------------------------------------------------------
st.title("Match vendor products to the PIM")
st.caption(
    "Upload a vendor file and your PIM export. Confident matches are accepted automatically; "
    "the rest go to a quick review queue."
)

tab_setup, tab_review, tab_export = st.tabs(["Upload and run", "Review", "Export"])

# --------------------------------------------------------------------------
# tab 1: upload + run
# --------------------------------------------------------------------------
with tab_setup:
    left, right = st.columns(2, gap="large")
    with left:
        st.subheader("Vendor file")
        vdf = load_file("CSV or Excel with the vendor's product names", "vendor")
        if vdf is not None:
            ss.vendor_df = vdf
            st.caption(f"{len(vdf):,} rows")
            st.dataframe(vdf.head(5), width="stretch", hide_index=True)
            vcols = column_picker("vendor", vdf)
    with right:
        st.subheader("PIM file")
        pdf = load_file("CSV or Excel exported from the PIM", "pim")
        if pdf is not None:
            ss.pim_df = pdf
            st.caption(f"{len(pdf):,} rows")
            st.dataframe(pdf.head(5), width="stretch", hide_index=True)
            pcols = column_picker("pim", pdf)

    with st.expander("Matching settings"):
        c1, c2, c3 = st.columns(3)
        auto_t = c1.slider(
            "Auto-accept at or above", 60, 100, 90,
            help="Matches scoring at least this much, with a clear lead over the next-best item, are accepted without review.",
        )
        review_t = c2.slider(
            "Send to review at or above", 30, 95, 70,
            help="Below this score a row is marked 'no match'.",
        )
        margin = c3.slider("Required lead over runner-up", 0, 20, 3)
        c4, c5, c6 = st.columns(3)
        size_pen = c4.slider("Size mismatch penalty", 0, 50, 25, help="Applied when pack sizes differ (500 g vs 1 kg).")
        brand_pen = c5.slider("Brand mismatch penalty", 0, 40, 15)
        top_k = c6.slider("Candidates kept per row", 2, 10, 5)

    with st.expander("Ask Claude about uncertain rows (optional)"):
        use_llm = st.checkbox("Use Claude on rows that need review")
        api_key = st.text_input(
            "Anthropic API key", type="password",
            value=os.environ.get("ANTHROPIC_API_KEY", ""),
            help="Only used for this session. You can also set ANTHROPIC_API_KEY before starting the app.",
        )
        model = st.text_input("Model", value=os.environ.get("PIM_MATCHER_MODEL", "claude-sonnet-5-5"))
        max_llm = st.number_input("Maximum rows to send", 10, 5000, 300, step=50)
        st.caption(
            "Claude only chooses among candidates the matcher already found. "
            "Its picks show up pre-selected in the review queue; you still confirm them."
        )

    ready = ss.vendor_df is not None and ss.pim_df is not None
    if st.button("Run matching", type="primary", disabled=not ready):
        bar = st.progress(0.0, text="Starting")

        def progress(done, total, stage):
            bar.progress(min(done / max(total, 1), 1.0), text=f"{stage}: {done:,} of {total:,}")

        cfg = MatchConfig(
            auto_threshold=auto_t, review_threshold=review_t, margin=margin,
            size_mismatch_penalty=size_pen, brand_mismatch_penalty=brand_pen, top_k=top_k,
        )
        try:
            ss.result = match(ss.vendor_df, ss.pim_df, vcols, pcols, cfg, progress)
            if use_llm:
                from pim_matcher.llm import refine_with_llm

                refine_with_llm(ss.result, model=model, max_rows=int(max_llm),
                                progress=progress, api_key=api_key or None)
            ss.decisions, ss.queue_pos = {}, 0
            bar.empty()
            n = (ss.result.table["status"].isin(REVIEW_STATUSES)).sum()
            st.success(f"Done. {n:,} rows need a look in the Review tab.")
        except Exception as e:
            bar.empty()
            st.error(f"Matching failed: {e}")
    if not ready:
        st.info("Upload both files to begin.")

# --------------------------------------------------------------------------
# tab 2: review
# --------------------------------------------------------------------------
with tab_review:
    res = ss.result
    if res is None:
        st.info("Run matching first.")
    else:
        t = res.table
        total = len(t)
        n_auto = int((t["status"] == "auto").sum())
        review_idx = [i for i in range(total) if t.at[i, "status"] in REVIEW_STATUSES]
        n_none = int((t["status"] == "no_match").sum())
        pending = [i for i in review_idx if i not in ss.decisions]

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Auto-matched", f"{n_auto:,}", pct(n_auto, total))
        m2.metric("Needs review", f"{len(review_idx):,}", f"{len(pending):,} left")
        m3.metric("No match", f"{n_none:,}", pct(n_none, total))
        m4.metric("Duplicates flagged", f"{int(t['duplicate_target'].sum()):,}",
                  help="Several vendor rows auto-matched to the same PIM item.")

        view = st.radio(
            "Show", ["Review queue", "Auto-matched", "No match", "All rows"],
            horizontal=True, label_visibility="collapsed",
        )

        if view != "Review queue":
            mask = {
                "Auto-matched": t["status"] == "auto",
                "No match": t["status"] == "no_match",
                "All rows": pd.Series(True, index=t.index),
            }[view]
            cols = ["vendor_id", "vendor_name", "status", "score", "pim_id", "pim_name", "notes", "duplicate_target"]
            st.dataframe(t.loc[mask, cols], width="stretch", hide_index=True)

        else:
            # ---- bulk accept -------------------------------------------------
            with st.expander("Accept many at once"):
                b1, b2 = st.columns([1, 2])
                min_score = b1.number_input("Minimum score", 50, 100, 85)
                eligible = [i for i in pending if t.at[i, "score"] >= min_score and res.candidates[i]]
                b2.write(f"{len(eligible):,} pending rows score {min_score} or higher.")
                if st.button("Accept top suggestion for these rows", disabled=not eligible):
                    for i in eligible:
                        ss.decisions[i] = res.candidates[i][0].pim_idx
                        # respect an LLM pick if there is one
                        if t.at[i, "status"] == "llm_suggested":
                            ss.decisions[i] = next(
                                (c.pim_idx for c in res.candidates[i] if c.pim_id == t.at[i, "pim_id"]),
                                res.candidates[i][0].pim_idx,
                            )
                    st.rerun()

            # ---- one-by-one --------------------------------------------------
            if not review_idx:
                st.success("Nothing to review. Everything was matched automatically or had no candidates.")
            elif not pending:
                st.success("All review items are decided. Head to the Export tab.")
            else:
                pos = ss.queue_pos % len(pending)
                i = pending[pos]
                row = t.iloc[i]
                cands = res.candidates[i]

                st.progress((len(review_idx) - len(pending)) / len(review_idx),
                            text=f"{len(review_idx) - len(pending)} of {len(review_idx)} reviewed")
                st.markdown(f"### {row['vendor_name']}")
                bits = [f"Vendor ID {row['vendor_id']}"]
                if row["vendor_brand"]:
                    bits.append(f"brand {row['vendor_brand']}")
                if row["vendor_size"]:
                    bits.append(f"size read as {row['vendor_size']}")
                st.caption(", ".join(bits))

                llm_reason = row.get("llm_reason", "") if "llm_reason" in t.columns else ""
                if llm_reason:
                    st.info(f"Claude ({row.get('llm_confidence', '')} confidence): {llm_reason}")

                default = 0
                if row["status"] == "llm_suggested":
                    default = next((n for n, c in enumerate(cands) if c.pim_id == row["pim_id"]), 0)

                choice = st.radio(
                    "Closest PIM items", list(range(len(cands))), index=default,
                    format_func=lambda n: candidate_label(cands[n]), key=f"pick_{i}",
                )
                if cands[choice].notes:
                    st.caption(cands[choice].notes)

                with st.expander("Not here? Search the PIM"):
                    q = st.text_input("Search by name", key=f"q_{i}")
                    manual = None
                    if q:
                        hits = res.search_pim(q, limit=10)
                        if hits:
                            k = st.selectbox(
                                "Results", list(range(len(hits))),
                                format_func=lambda n: f"{hits[n].pim_name} [{hits[n].pim_brand}]",
                                key=f"qs_{i}",
                            )
                            manual = hits[k]
                        else:
                            st.write("No results.")
                    use_manual = st.checkbox("Use the search result instead", key=f"um_{i}", disabled=manual is None)

                b1, b2, b3 = st.columns(3)
                if b1.button("Confirm match", type="primary", key=f"ok_{i}"):
                    ss.decisions[i] = manual.pim_idx if (use_manual and manual) else cands[choice].pim_idx
                    st.rerun()
                if b2.button("No match in PIM", key=f"none_{i}"):
                    ss.decisions[i] = None
                    st.rerun()
                if b3.button("Skip for now", key=f"skip_{i}"):
                    ss.queue_pos += 1
                    st.rerun()

# --------------------------------------------------------------------------
# tab 3: export
# --------------------------------------------------------------------------
with tab_export:
    res = ss.result
    if res is None:
        st.info("Run matching first.")
    else:
        final = res.finalize(ss.decisions)
        counts = final["final_status"].value_counts()
        st.write("Final status of every vendor row:")
        st.dataframe(counts.rename("rows").to_frame(), width="stretch")
        if (final["final_status"] == "unreviewed").any():
            st.warning("Some rows are still unreviewed. They are exported without a PIM match.")

        simple = st.checkbox("Only the essential columns", value=True)
        out = final
        if simple:
            keep = ["final_status", "final_pim_id", "final_pim_name", "vendor_row", "vendor_id",
                    "vendor_name", "vendor_brand", "score", "method", "notes"]
            out = final[[c for c in keep if c in final.columns]]
        st.dataframe(out.head(200), width="stretch", hide_index=True)

        d1, d2 = st.columns(2)
        d1.download_button("Download Excel", to_excel_bytes(out), "vendor_pim_matches.xlsx",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary")
        d2.download_button("Download CSV", to_csv_bytes(out), "vendor_pim_matches.csv", "text/csv")
