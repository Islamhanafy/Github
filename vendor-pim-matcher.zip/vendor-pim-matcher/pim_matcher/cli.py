"""Command-line usage:

python -m pim_matcher.cli --vendor vendor.csv --pim pim.csv \
    --vendor-name product --pim-name product_name --out matches.xlsx
"""
from __future__ import annotations

import argparse
import sys

from .engine import MatchConfig, match
from .io import guess_columns, read_table, to_csv_bytes, to_excel_bytes


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Match vendor product names to PIM product names.")
    ap.add_argument("--vendor", required=True, help="vendor file (csv/xlsx)")
    ap.add_argument("--pim", required=True, help="PIM file (csv/xlsx)")
    ap.add_argument("--out", default="matches.xlsx", help="output file (.xlsx or .csv)")
    for side in ("vendor", "pim"):
        for key in ("name", "id", "brand", "barcode"):
            ap.add_argument(f"--{side}-{key}", help=f"{side} {key} column (auto-detected if omitted)")
    ap.add_argument("--auto", type=float, default=90, help="auto-match threshold (default 90)")
    ap.add_argument("--review", type=float, default=70, help="review threshold (default 70)")
    ap.add_argument("--llm", action="store_true", help="ask Claude about rows that need review")
    ap.add_argument("--llm-model", default=None)
    a = ap.parse_args(argv)

    v, p = read_table(a.vendor), read_table(a.pim)
    vg, pg = guess_columns(v), guess_columns(p)
    vcols = {k: getattr(a, f"vendor_{k}") or vg.get(k) for k in ("name", "id", "brand", "barcode")}
    pcols = {k: getattr(a, f"pim_{k}") or pg.get(k) for k in ("name", "id", "brand", "barcode")}
    print(f"vendor columns: {vcols}\npim columns:    {pcols}")

    def progress(done, total, stage):
        print(f"\r{stage}: {done}/{total}", end="", file=sys.stderr)

    cfg = MatchConfig(auto_threshold=a.auto, review_threshold=a.review)
    res = match(v, p, vcols, pcols, cfg, progress)
    print(file=sys.stderr)

    if a.llm:
        from .llm import DEFAULT_MODEL, refine_with_llm

        n = refine_with_llm(res, model=a.llm_model or DEFAULT_MODEL, progress=progress)
        print(f"\nLLM reviewed {n} rows", file=sys.stderr)

    out = res.finalize({})
    if a.out.lower().endswith(".csv"):
        open(a.out, "wb").write(to_csv_bytes(out))
    else:
        open(a.out, "wb").write(to_excel_bytes(out))
    print(out["status"].value_counts().to_string())
    print(f"saved -> {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
