"""Matching engine: vendor product names -> PIM product names.

Pipeline
  1. Normalise names, extract pack size, brand and barcode.
  2. Candidate retrieval: TF-IDF over character n-grams (fast, typo tolerant),
     plus exact barcode lookup when both sides have one.
  3. Re-score candidates with fuzzy text similarity, adjusted for size, brand
     and model-number agreement.
  4. Classify each vendor row as auto / review / no_match.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable

import numpy as np
import pandas as pd
from rapidfuzz import fuzz, process
from sklearn.feature_extraction.text import TfidfVectorizer

from .normalize import (
    DEFAULT_SYNONYMS,
    Parsed,
    normalize_code,
    normalize_simple,
    parse_name,
)

ProgressFn = Callable[[int, int, str], None]


# --------------------------------------------------------------------------
# Config / data classes
# --------------------------------------------------------------------------
@dataclass
class MatchConfig:
    auto_threshold: float = 90.0  # >= this (and clear lead) -> auto match
    review_threshold: float = 70.0  # >= this -> needs human review, else no match
    margin: float = 3.0  # min lead over runner-up for auto match
    top_k: int = 5  # candidates kept per vendor row
    candidate_pool: int = 40  # candidates pulled from TF-IDF before re-scoring
    size_match_bonus: float = 4.0
    size_mismatch_penalty: float = 25.0
    brand_match_bonus: float = 4.0
    brand_mismatch_penalty: float = 15.0
    number_mismatch_penalty: float = 15.0
    synonyms: dict = field(default_factory=lambda: dict(DEFAULT_SYNONYMS))


@dataclass
class Candidate:
    pim_idx: int
    pim_id: str
    pim_name: str
    pim_brand: str
    score: float
    notes: str
    method: str  # "name" or "barcode"


@dataclass
class Item:
    idx: int
    id: str
    name: str
    brand_raw: str
    brand: str
    code: str
    parsed: Parsed


@dataclass
class MatchResult:
    table: pd.DataFrame
    candidates: list[list[Candidate]]
    vendor_df: pd.DataFrame
    pim_df: pd.DataFrame
    vendor_cols: dict
    pim_cols: dict
    pim_items: list[Item]
    pim_norm: list[str]

    # ---- mutation helpers ------------------------------------------------
    def set_match(self, pos: int, cand: Candidate | None, status: str, **extra) -> None:
        t = self.table
        t.at[pos, "status"] = status
        if cand is not None:
            t.at[pos, "pim_id"] = cand.pim_id
            t.at[pos, "pim_name"] = cand.pim_name
            t.at[pos, "pim_brand"] = cand.pim_brand
            t.at[pos, "score"] = round(cand.score, 1)
            t.at[pos, "method"] = cand.method
            t.at[pos, "notes"] = cand.notes
        for k, v in extra.items():
            if k not in t.columns:
                t[k] = ""
            t.at[pos, k] = v

    # ---- lookups ---------------------------------------------------------
    def search_pim(self, query: str, limit: int = 10) -> list[Candidate]:
        """Free-text search over the PIM (used for manual matching in the UI)."""
        q = parse_name(query).core or normalize_simple(query)
        if not q:
            return []
        hits = process.extract(q, self.pim_norm, scorer=fuzz.WRatio, limit=limit)
        out = []
        for _, score, j in hits:
            p = self.pim_items[j]
            out.append(Candidate(j, p.id, p.name, p.brand_raw, float(score), "manual search", "search"))
        return out

    # ---- final output ----------------------------------------------------
    def finalize(self, decisions: dict[int, int | None]) -> pd.DataFrame:
        """Merge automatic results with human decisions.

        decisions: {vendor row position: pim item index, or None for 'no match'}
        """
        df = self.table.copy()
        f_status, f_id, f_name = [], [], []
        for pos, row in df.iterrows():
            if pos in decisions:
                j = decisions[pos]
                if j is None:
                    f_status.append("no_match (reviewed)")
                    f_id.append("")
                    f_name.append("")
                else:
                    p = self.pim_items[j]
                    top = self.candidates[pos][0].pim_idx if self.candidates[pos] else None
                    f_status.append("confirmed" if j == top else "manual")
                    f_id.append(p.id)
                    f_name.append(p.name)
            elif row["status"] == "auto":
                f_status.append("auto")
                f_id.append(row["pim_id"])
                f_name.append(row["pim_name"])
            elif row["status"] == "no_match":
                f_status.append("no_match")
                f_id.append("")
                f_name.append("")
            else:
                f_status.append("unreviewed")
                f_id.append("")
                f_name.append("")
        df.insert(0, "final_status", f_status)
        df.insert(1, "final_pim_id", f_id)
        df.insert(2, "final_pim_name", f_name)
        return df


# --------------------------------------------------------------------------
# Preparation
# --------------------------------------------------------------------------
def _col(df: pd.DataFrame, name: str | None, i: int) -> str:
    if not name or name not in df.columns:
        return ""
    v = df.iloc[i][name]
    return "" if pd.isna(v) else str(v).strip()


def _prepare(df: pd.DataFrame, cols: dict, synonyms: dict) -> list[Item]:
    items = []
    for i in range(len(df)):
        name = _col(df, cols.get("name"), i)
        brand_raw = _col(df, cols.get("brand"), i)
        items.append(
            Item(
                idx=i,
                id=_col(df, cols.get("id"), i) or str(i + 1),
                name=name,
                brand_raw=brand_raw,
                brand=normalize_simple(brand_raw),
                code=normalize_code(_col(df, cols.get("barcode"), i)),
                parsed=parse_name(name, synonyms),
            )
        )
    return items


def _text_for_index(it: Item) -> str:
    return it.parsed.core or normalize_simple(it.name)


# --------------------------------------------------------------------------
# Candidate retrieval
# --------------------------------------------------------------------------
def _retrieve(V: list[Item], P: list[Item], pool: int, progress: ProgressFn | None) -> list[np.ndarray]:
    if not P:
        return [np.array([], dtype=int) for _ in V]
    tp = [_text_for_index(p) for p in P]
    tv = [_text_for_index(v) for v in V]
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), sublinear_tf=True, dtype=np.float32)
    vec.fit(tp + tv)
    Mp = vec.transform(tp).T.tocsc()
    Mv = vec.transform(tv).tocsr()

    k = min(pool, len(P))
    chunk = max(50, int(2e7 // max(len(P), 1)))
    out: list[np.ndarray] = []
    for a in range(0, len(V), chunk):
        S = (Mv[a : a + chunk] @ Mp).toarray()
        if k < S.shape[1]:
            part = np.argpartition(-S, k - 1, axis=1)[:, :k]
        else:
            part = np.tile(np.arange(S.shape[1]), (S.shape[0], 1))
        out.extend(part)
        if progress:
            progress(min(a + chunk, len(V)), len(V), "Finding candidates")
    return out


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------
def _fmt(x) -> str:
    return str(x) if x is not None else "?"


@lru_cache(maxsize=2_000_000)
def _tok_ratio(a: str, b: str) -> float:
    return fuzz.ratio(a, b)


def _coverage(small: frozenset, large: frozenset) -> float:
    """Share of `small` tokens that (fuzzily) appear in `large`, 0..1."""
    if not small:
        return 0.0
    if not large:
        return 0.0
    total = sum(max(_tok_ratio(t, u) for u in large) for t in small)
    return total / (100.0 * len(small))


def score_pair(v: Item, p: Item, cfg: MatchConfig) -> tuple[float, list[str]]:
    a, b = v.parsed.core, p.parsed.core
    notes: list[str] = []

    if a and b:
        ts = fuzz.token_sort_ratio(a, b)
        tset = fuzz.token_set_ratio(a, b)
        r = fuzz.ratio(a, b)
        chars = 0.45 * ts + 0.30 * tset + 0.25 * r
        # Vendor names are often shorter than PIM names ("Nescafe Gold 100gm" vs
        # "Nescafe Gold Instant Coffee 100g"), so also reward the shorter name
        # being fully contained in the longer one.
        ta, tb = v.parsed.tokens, p.parsed.tokens
        small, large = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
        cov = 100.0 * (0.7 * _coverage(small, large) + 0.3 * _coverage(large, small))
        text = 0.5 * chars + 0.5 * cov
    else:
        text = 0.0
    score = text

    # model numbers / variants (e.g. "iphone 14" vs "iphone 15")
    na, nb = v.parsed.numbers, p.parsed.numbers
    if na and nb and na != nb:
        score -= cfg.number_mismatch_penalty
        notes.append(f"number mismatch ({', '.join(sorted(na))} vs {', '.join(sorted(nb))})")

    # pack size
    sa, sb = v.parsed.size, p.parsed.size
    if sa and sb and sa.kind == sb.kind:
        if abs(sa.value - sb.value) <= 0.01 * max(sa.value, sb.value):
            score += cfg.size_match_bonus
            notes.append(f"size match ({sa})")
        else:
            score -= cfg.size_mismatch_penalty
            notes.append(f"size mismatch ({sa} vs {sb})")
    elif sa and sb:
        score -= cfg.size_mismatch_penalty / 2
        notes.append(f"unit type differs ({sa} vs {sb})")
    elif sa or sb:
        notes.append("size only on one side")

    # brand
    if v.brand and p.brand:
        # same brand, or one side's brand is spelled out in the other's name
        # (e.g. brand "Ferrero" vs "Nutella" when the vendor name says Nutella)
        same = (
            fuzz.ratio(v.brand, p.brand) >= 85
            or v.brand in p.parsed.core
            or p.brand in v.parsed.core
        )
        if same:
            score += cfg.brand_match_bonus
        else:
            score -= cfg.brand_mismatch_penalty
            notes.append(f"brand mismatch ({v.brand_raw} vs {p.brand_raw})")

    return max(0.0, min(100.0, score)), notes


# --------------------------------------------------------------------------
# Main entry point
# --------------------------------------------------------------------------
def match(
    vendor_df: pd.DataFrame,
    pim_df: pd.DataFrame,
    vendor_cols: dict,
    pim_cols: dict,
    cfg: MatchConfig | None = None,
    progress: ProgressFn | None = None,
) -> MatchResult:
    """Match every row of vendor_df to the best rows of pim_df.

    vendor_cols / pim_cols: {"name": col, "id": col|None, "brand": col|None, "barcode": col|None}
    """
    cfg = cfg or MatchConfig()
    vendor_df = vendor_df.reset_index(drop=True)
    pim_df = pim_df.reset_index(drop=True)
    V = _prepare(vendor_df, vendor_cols, cfg.synonyms)
    P = _prepare(pim_df, pim_cols, cfg.synonyms)

    code_index: dict[str, list[int]] = defaultdict(list)
    for p in P:
        if p.code:
            code_index[p.code].append(p.idx)

    pool = _retrieve(V, P, cfg.candidate_pool, progress)

    all_cands: list[list[Candidate]] = []
    rows = []
    for i, v in enumerate(V):
        picked: dict[int, str] = {int(j): "name" for j in pool[i]}
        if v.code:
            for j in code_index.get(v.code, []):
                picked[j] = "barcode"

        scored: list[Candidate] = []
        for j, how in picked.items():
            p = P[j]
            s, notes = score_pair(v, p, cfg)
            if how == "barcode":
                if s < 50:
                    notes.append(f"barcode matches but names differ (text score {s:.0f})")
                else:
                    notes.append("barcode match")
                s = 100.0
            scored.append(Candidate(j, p.id, p.name, p.brand_raw, s, "; ".join(notes), how))
        scored.sort(key=lambda c: (-c.score, c.pim_idx))
        scored = scored[: cfg.top_k]
        all_cands.append(scored)

        top = scored[0] if scored else None
        second = scored[1].score if len(scored) > 1 else 0.0
        if top is None:
            status = "no_match"
        elif top.score >= cfg.auto_threshold and (
            top.method == "barcode" or top.score - second >= cfg.margin
        ):
            status = "auto"
        elif top.score >= cfg.review_threshold:
            status = "review"
        else:
            status = "no_match"

        keep = status != "no_match" and top is not None
        rows.append(
            {
                "vendor_row": i + 2,  # 1-based row in the source file, header = row 1
                "vendor_id": v.id,
                "vendor_name": v.name,
                "vendor_brand": v.brand_raw,
                "vendor_size": str(v.parsed.size) if v.parsed.size else "",
                "status": status,
                "score": round(top.score, 1) if top else 0.0,
                "method": top.method if top and keep else "",
                "pim_id": top.pim_id if keep else "",
                "pim_name": top.pim_name if keep else "",
                "pim_brand": top.pim_brand if keep else "",
                "notes": top.notes if top else "",
                "runner_up_score": round(second, 1),
                "alt_1": f"{scored[1].pim_name} ({scored[1].score:.0f})" if len(scored) > 1 else "",
                "alt_2": f"{scored[2].pim_name} ({scored[2].score:.0f})" if len(scored) > 2 else "",
            }
        )
        if progress and (i % 25 == 0 or i == len(V) - 1):
            progress(i + 1, len(V), "Scoring matches")

    table = pd.DataFrame(rows)
    # flag PIM items claimed by several auto-matched vendor rows
    auto = table[table["status"] == "auto"]
    dup_ids = set(auto["pim_id"][auto["pim_id"].duplicated(keep=False)])
    table["duplicate_target"] = table["pim_id"].isin(dup_ids) & (table["status"] == "auto")

    return MatchResult(
        table=table,
        candidates=all_cands,
        vendor_df=vendor_df,
        pim_df=pim_df,
        vendor_cols=vendor_cols,
        pim_cols=pim_cols,
        pim_items=P,
        pim_norm=[_text_for_index(p) for p in P],
    )
