"""Text normalisation and size parsing for product names (English + Arabic)."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

# --- Arabic handling -------------------------------------------------------
_AR_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]")
_AR_MAP = str.maketrans(
    {"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي"}
)
# Arabic-Indic and Persian digits -> ASCII
_DIGIT_MAP = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

# --- Units -----------------------------------------------------------------
# name -> (base kind, factor to base unit)
_UNIT_TABLE: dict[str, tuple[str, float]] = {}


def _reg(names: str, kind: str, factor: float) -> None:
    for n in names.split():
        _UNIT_TABLE[n] = (kind, factor)


_reg("kg kgs kilo kilos kilogram kilograms كجم كيلو كغ كغم", "g", 1000)
_reg("g gm gms gr grm gram grams جم جرام غ غرام غم", "g", 1)
_reg("mg", "g", 0.001)
_reg("oz", "g", 28.35)
_reg("l lt ltr ltrs liter liters litre litres لتر", "ml", 1000)
_reg("ml mls مل", "ml", 1)
_reg("cl", "ml", 10)
_reg("gb gigabyte gigabytes", "gb", 1)
_reg("tb terabyte terabytes", "gb", 1024)
_reg("mb", "gb", 1 / 1024)
_reg("pcs pc piece pieces pack packs pk ct count bag bags sachet sachets حبه قطعه قطع", "count", 1)

_UNIT_RE = "|".join(sorted(map(re.escape, _UNIT_TABLE), key=len, reverse=True))
_NUM = r"\d+(?:\.\d+)?"
# Handles: "500g", "1.5 L", "6 x 330ml", "330ml x 6"
_SIZE_RE = re.compile(
    rf"(?<![\w.])(?:(?P<pre>\d+)\s*[x×*]\s*)?(?P<val>{_NUM})\s*(?P<unit>{_UNIT_RE})"
    rf"(?![a-z\u0600-\u06ff])(?:\s*[x×*]\s*(?P<post>\d+)(?!\d))?"
)

STOPWORDS = frozenset({"the", "and", "of", "with", "for", "a", "an"})

# Token-level replacements applied after cleaning. Edit freely.
DEFAULT_SYNONYMS = {
    "choc": "chocolate",
    "chkn": "chicken",
    "org": "organic",
    "btl": "bottle",
    "pkt": "packet",
    "coke": "coca cola",
}


@dataclass(frozen=True)
class Size:
    kind: str  # "g", "ml" or "count"
    value: float

    def __str__(self) -> str:
        unit = {"g": "g", "ml": "ml", "count": "pcs", "gb": "GB"}[self.kind]
        v = int(self.value) if float(self.value).is_integer() else round(self.value, 2)
        return f"{v} {unit}"


@dataclass(frozen=True)
class Parsed:
    raw: str
    core: str  # normalised, size removed, stop-words removed
    tokens: frozenset
    numbers: frozenset
    size: Size | None


def _basic_clean(text: object) -> str:
    if text is None or (isinstance(text, float) and text != text):
        return ""
    s = unicodedata.normalize("NFKC", str(text)).translate(_DIGIT_MAP).lower()
    s = _AR_DIACRITICS.sub("", s).translate(_AR_MAP)
    s = s.replace("&", " and ")
    s = re.sub(r"(?<=\d),(?=\d{1,2}(?!\d))", ".", s)  # 1,5 -> 1.5
    s = re.sub(r"[^\w\s.×*]", " ", s).replace("_", " ")
    return re.sub(r"\s+", " ", s).strip()


def parse_name(text: object, synonyms: dict[str, str] | None = None) -> Parsed:
    """Normalise a product name and pull out its size (if any)."""
    synonyms = DEFAULT_SYNONYMS if synonyms is None else synonyms
    s = _basic_clean(text)
    found: list[Size] = []

    def repl(m: re.Match) -> str:
        kind, factor = _UNIT_TABLE[m.group("unit")]
        qty = float(m.group("val")) * factor
        mult = int(m.group("pre") or m.group("post") or 1)
        if not found:  # first size wins
            found.append(Size(kind, round(qty * mult, 3)))
        return " "

    s = _SIZE_RE.sub(repl, s)
    s = re.sub(r"(?<!\d)\.|\.(?!\d)", " ", s)  # stray dots
    s = s.replace("×", " ").replace("*", " ")

    tokens: list[str] = []
    for t in s.split():
        for piece in synonyms.get(t, t).split():
            if piece not in STOPWORDS and piece != "x":
                tokens.append(piece)

    return Parsed(
        raw="" if text is None else str(text),
        core=" ".join(tokens),
        tokens=frozenset(tokens),
        numbers=frozenset(t for t in tokens if any(c.isdigit() for c in t)),
        size=found[0] if found else None,
    )


def normalize_simple(text: object) -> str:
    """Light normalisation used for brands and free-text search."""
    return _basic_clean(text)


def normalize_code(text: object) -> str:
    """Barcode / GTIN: digits only, leading zeros stripped; '' if too short."""
    digits = re.sub(r"\D", "", "" if text is None else str(text))
    digits = digits.lstrip("0")
    return digits if len(digits) >= 6 else ""
