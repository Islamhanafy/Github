"""Optional LLM second opinion for rows that need review.

Requires the `anthropic` package and an ANTHROPIC_API_KEY environment variable.
The LLM only picks among the candidates the engine already found; it never
invents a PIM item. Its answer is stored as a *suggestion* (status
"llm_suggested") and still goes through human review.
"""
from __future__ import annotations

import json
import os
import re
from concurrent.futures import ThreadPoolExecutor

from .engine import MatchResult

DEFAULT_MODEL = os.environ.get("PIM_MATCHER_MODEL", "claude-sonnet-5-5")

SYSTEM = (
    "You are a product-catalogue specialist. You decide whether a vendor's product "
    "listing is the SAME sellable product as one of the candidate PIM items. "
    "Same product means same brand, same variant/flavour/type, and same pack size. "
    "Differences in word order, abbreviations, language, or extra marketing words are fine. "
    "A different size, flavour, model number or variant means it is NOT the same product. "
    'Reply with JSON only: {"choice": <candidate number or null>, '
    '"confidence": "high"|"medium"|"low", "reason": "<one short sentence>"}'
)


def _prompt(result: MatchResult, pos: int) -> str:
    row = result.table.iloc[pos]
    lines = [
        "Vendor item:",
        f"  name: {row['vendor_name']}",
        f"  brand: {row['vendor_brand'] or '-'}",
        f"  parsed size: {row['vendor_size'] or '-'}",
        "",
        "Candidates:",
    ]
    for n, c in enumerate(result.candidates[pos], 1):
        lines.append(f"  {n}. {c.pim_name} | brand: {c.pim_brand or '-'} | similarity {c.score:.0f}")
    lines.append("\nIf none is the same product, use null.")
    return "\n".join(lines)


def _ask(client, model: str, prompt: str) -> dict:
    msg = client.messages.create(
        model=model,
        max_tokens=300,
        system=SYSTEM,
        messages=[{"role": "user", "content": prompt}],
    )
    text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0)) if m else {}


def refine_with_llm(
    result: MatchResult,
    model: str = DEFAULT_MODEL,
    max_rows: int = 500,
    workers: int = 4,
    progress=None,
    api_key: str | None = None,
) -> int:
    """Ask the LLM about rows with status 'review'. Returns number of rows processed."""
    import anthropic  # imported lazily so the rest of the package works without it

    client = anthropic.Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
    todo = [
        i for i in range(len(result.table))
        if result.table.at[i, "status"] == "review" and result.candidates[i]
    ][:max_rows]

    for col in ("llm_confidence", "llm_reason"):
        if col not in result.table.columns:
            result.table[col] = ""

    def work(pos: int):
        try:
            return pos, _ask(client, model, _prompt(result, pos)), None
        except Exception as e:  # keep going if a single call fails
            return pos, {}, str(e)

    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for pos, ans, err in ex.map(work, todo):
            done += 1
            if err:
                result.table.at[pos, "llm_reason"] = f"LLM error: {err[:120]}"
            else:
                choice = ans.get("choice")
                conf = str(ans.get("confidence", "low")).lower()
                reason = str(ans.get("reason", ""))
                cands = result.candidates[pos]
                if isinstance(choice, int) and 1 <= choice <= len(cands) and conf in ("high", "medium"):
                    result.set_match(
                        pos, cands[choice - 1], "llm_suggested",
                        llm_confidence=conf, llm_reason=reason,
                    )
                else:
                    result.table.at[pos, "llm_confidence"] = conf
                    result.table.at[pos, "llm_reason"] = reason or "LLM found no matching candidate"
            if progress:
                progress(done, len(todo), "Asking the LLM")
    return len(todo)
