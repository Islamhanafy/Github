"""Reading and writing tables (CSV / Excel), plus column-name guessing."""
from __future__ import annotations

import io
from pathlib import Path

import pandas as pd


def _raw_bytes(source) -> bytes:
    if hasattr(source, "getvalue"):
        return source.getvalue()
    if hasattr(source, "read"):
        return source.read()
    return Path(source).read_bytes()


def _name_of(source, name: str | None) -> str:
    return (name or getattr(source, "name", None) or str(source)).lower()


def list_sheets(source, name: str | None = None) -> list[str]:
    if not _name_of(source, name).endswith((".xlsx", ".xlsm", ".xls")):
        return []
    return pd.ExcelFile(io.BytesIO(_raw_bytes(source))).sheet_names


def read_table(source, name: str | None = None, sheet: str | int | None = None) -> pd.DataFrame:
    """Read a CSV/TSV/Excel file (path or uploaded file) as text, empty cells as ''."""
    fname = _name_of(source, name)
    raw = _raw_bytes(source)
    if fname.endswith((".xlsx", ".xlsm", ".xls")):
        df = pd.read_excel(io.BytesIO(raw), sheet_name=sheet if sheet is not None else 0, dtype=str)
    else:
        if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
            encodings = ["utf-16"]
        else:
            encodings = ["utf-8-sig", "cp1256", "latin-1"]  # cp1256 = Arabic Windows
        df, last = None, None
        for enc in encodings:
            try:
                df = pd.read_csv(io.BytesIO(raw), dtype=str, sep=None, engine="python", encoding=enc)
                break
            except Exception as e:  # try the next encoding
                last = e
        if df is None:
            raise ValueError(f"Could not read {fname}: {last}")
    df.columns = [str(c).strip() for c in df.columns]
    return df.fillna("")


_HINTS = {
    "name": ["product name", "product_name", "item name", "item_name", "description", "title", "name", "product", "item"],
    "id": ["sku", "vendor_sku", "product id", "product_id", "item id", "item_id", "pim id", "pim_id", "code", "id"],
    "brand": ["brand", "manufacturer", "make"],
    "barcode": ["barcode", "gtin", "ean", "upc"],
}


def guess_columns(df: pd.DataFrame) -> dict:
    """Best-guess {name, id, brand, barcode} columns from header names."""
    lowered = {c: c.lower().replace("-", "_") for c in df.columns}
    out: dict[str, str | None] = {}
    for key, hints in _HINTS.items():
        found = None
        for h in hints:  # earlier hints are more specific
            for col, low in lowered.items():
                if col in out.values():
                    continue
                if h in low:
                    found = col
                    break
            if found:
                break
        out[key] = found
    if out["name"] is None and len(df.columns):
        out["name"] = df.columns[0]
    return out


def to_excel_bytes(df: pd.DataFrame, sheet_name: str = "matches") -> bytes:
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        df.to_excel(xw, index=False, sheet_name=sheet_name)
        ws = xw.sheets[sheet_name]
        ws.freeze_panes = "A2"
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="E6EEF0")
        for i, col in enumerate(df.columns, 1):
            width = min(60, max(10, int(df[col].astype(str).str.len().quantile(0.9)) + 2, len(str(col)) + 2))
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.auto_filter.ref = ws.dimensions
    return buf.getvalue()


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")  # BOM so Excel shows Arabic correctly
